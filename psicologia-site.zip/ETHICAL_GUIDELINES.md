# Diretrizes Éticas - Site de Psicologia

## Preceitos Éticos Implementados

Este site foi desenvolvido seguindo rigorosamente os preceitos éticos da profissão de psicólogo, conforme estabelecido pelo Conselho Federal de Psicologia (CFP) e regulamentações internacionais.

### 1. Sigilo e Confidencialidade
- O site não coleta dados pessoais desnecessários
- Qualquer informação compartilhada durante o agendamento é protegida
- Política de privacidade clara e acessível
- Conformidade com LGPD (Lei Geral de Proteção de Dados)

### 2. Linguagem Responsável
- ✅ Evita promessas de "cura" ou resultados garantidos
- ✅ Usa linguagem que reconhece a complexidade do sofrimento humano
- ✅ Apresenta a terapia como um processo colaborativo, não prescritivo
- ✅ Reconhece limitações e quando encaminhamentos são necessários

### 3. Informações sobre Emergências
- Deve incluir orientações claras sobre o que fazer em situações de crise
- Números de telefone de emergência (CVV, SAMU, etc.)
- Recomendação clara: em emergências, procure atendimento imediato

### 4. Credenciais Profissionais
- Deve incluir número de registro no Conselho Regional de Psicologia (CRP)
- Formação acadêmica verificável (USP)
- Especializações e áreas de atuação claramente definidas

### 5. Consentimento Informado
- Primeira sessão deve incluir explicação clara sobre:
  - Como funciona o atendimento
  - Direitos e responsabilidades do cliente
  - Limites da confidencialidade
  - Possibilidade de encaminhamento para outro profissional

### 6. Não-Discriminação
- Atendimento respeitoso a todas as pessoas
- Sem julgamentos sobre orientação sexual, identidade de gênero, religião, etc.
- Compromisso com equidade e inclusão

### 7. Competência Profissional
- Apenas oferecer serviços dentro da área de competência
- Reconhecer quando encaminhamento é necessário
- Manter-se atualizado com pesquisa e práticas baseadas em evidências

### 8. Relação Profissional
- Manter limites claros entre relação profissional e pessoal
- Evitar conflitos de interesse
- Não oferecer atendimento a pessoas com quem há relacionamento pessoal

### 9. Transparência sobre Limitações
- Deixar claro que o atendimento online tem limitações específicas
- Não é adequado para todas as situações clínicas
- Alguns casos requerem atendimento presencial

### 10. Respeito à Autonomia
- O cliente é o especialista em sua própria vida
- Decisões são tomadas em conjunto
- Respeito ao direito de recusa ou interrupção do tratamento

## Implementação no Site

### Seções Obrigatórias a Incluir:
1. **Aviso de Emergência** - Topo do site ou seção FAQ
2. **Credenciais Profissionais** - Seção "Sobre Mim"
3. **Política de Privacidade** - Rodapé
4. **Termos de Serviço** - Rodapé
5. **Limitações do Atendimento Online** - FAQ ou seção específica
6. **Consentimento Informado** - Antes de agendar

### Linguagem Recomendada:

**Em vez de:** "Vou curar sua ansiedade"
**Use:** "Vou ajudá-lo a desenvolver ferramentas para lidar melhor com a ansiedade"

**Em vez de:** "Garantido resultado em 10 sessões"
**Use:** "Cada processo é único; trabalharemos no seu ritmo"

**Em vez de:** "Sou o melhor psicólogo"
**Use:** "Tenho experiência em... e estou comprometido com sua bem-estar"

## Referências Normativas
- Código de Ética Profissional do Psicólogo (CFP)
- Resolução CFP nº 4/2020 (Atendimento psicológico online)
- Lei Geral de Proteção de Dados (LGPD)
- Diretrizes da APA (American Psychological Association)

## Checklist de Conformidade

- [ ] Site inclui aviso de emergência claro
- [ ] Credenciais profissionais verificáveis
- [ ] Política de privacidade em conformidade com LGPD
- [ ] Linguagem evita promessas de cura
- [ ] FAQ inclui informações sobre limitações
- [ ] Contato direto para agendamento (sem automação)
- [ ] Termo de consentimento informado disponível
- [ ] Informações sobre sigilo e confidencialidade
- [ ] Orientações sobre quando procurar emergência
- [ ] Sem discriminação ou conteúdo prejudicial

---

**Última atualização:** Maio 2026
**Responsável:** [Nome do Psicólogo]
**CRP:** [Número de Registro]

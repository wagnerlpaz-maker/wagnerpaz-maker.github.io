import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronDown, Phone, Mail, MapPin, Heart, Briefcase, MessageCircle, CheckCircle, AlertCircle } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const whatsappLink = "https://wa.me/5519971708373?text=Olá,%20gostaria%20de%20agendar%20uma%20sessão";
  const phoneNumber = "(19) 97170-8373";
  const crpNumber = "06-233592";
  const psychologistName = "Wagner Paz";

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background border-b border-secondary">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img 
              src="/manus-storage/wagner-paz-logo-updated_fa94a569.png"
              alt="Wagner Paz Psicólogo"
              className="h-80 w-auto"
            />
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#sobre" className="text-foreground hover:text-primary transition-colors">Sobre</a>
            <a href="#servicos" className="text-foreground hover:text-primary transition-colors">Serviços</a>
            <a href="#metodo" className="text-foreground hover:text-primary transition-colors">Método</a>
            <a href="#faq" className="text-foreground hover:text-primary transition-colors">FAQ</a>
            <a href="#contato" className="text-foreground hover:text-primary transition-colors">Contato</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028397627/Htz5MNH74SXz44txpSQmVV/hero-background-VtTwth3wBugpcpT8iW9dHv.webp"
            alt="Background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent"></div>
        </div>

        <div className="container mx-auto px-4 py-24 md:py-32 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1 className="hero-title">
                Você não precisa carregar o peso de todas as escolhas sozinho.
              </h1>
              
              <p className="text-lg text-foreground/80 leading-relaxed max-w-lg">
                Psicoterapia e Orientação de Carreira para jovens e adultos. Um espaço de escuta genuína, horizontal e seguro, focado em resgatar a sua autonomia diante da ansiedade e do esgotamento diário.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                  <Button className="btn-primary w-full sm:w-auto">
                    Agendar Sessão
                  </Button>
                </a>
              </div>

              <div className="flex gap-6 pt-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-accent" />
                  <span className="text-sm text-foreground/70">Atendimento Online</span>
                </div>
              </div>
            </div>

            <div className="hidden md:block relative h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-secondary/20 to-accent/10 rounded-2xl"></div>
              <img 
                src="/manus-storage/wagner-paz-professional-ultra-hq_41063025.png"
                alt="Foto Profissional - Wagner Paz"
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pain Point Section */}
      <section className="section-padding bg-muted/30">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="section-title">É comum sentir que algo saiu dos trilhos</h2>
            <div className="accent-line mx-auto"></div>
            
            <p className="text-lg text-foreground/80 leading-relaxed">
              Se você está carregando tristeza, melancolia, insegurança e sentimentos de depressão que parecem não ter saída, ou ainda lidando com ansiedade constante e sensação de burnout no trabalho, saiba que essa dor é válida e merece ser acolhida. Conflitos nas relações e paralisia na hora de tomar decisões também fazem parte dessa jornada. Existe um caminho possível para reorganizar essa rota com mais leveza e clareza.
            </p>

            <p className="text-base text-foreground/70 italic">
              Você não está sozinho nessa jornada.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicos" className="section-padding">
        <div className="container mx-auto">
          <h2 className="section-title text-center mb-12">Como Trabalhamos Juntos</h2>
          <div className="accent-line mx-auto mb-12"></div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Service 1 */}
            <Card className="card-minimal hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4 mb-4">
                <Heart className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <h3 className="font-display text-2xl text-primary">Psicoterapia Clínica</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed mb-4">
                Trabalho colaborativo focado em compreender sua história e contexto. Juntos, exploramos as raízes de ansiedade, estresse e conflitos, desenvolvendo estratégias práticas para retomar a sua autonomia e bem-estar em diferentes fases da vida.
              </p>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Ansiedade e depressão: compreender e reorganizar
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Estresse crônico e esgotamento: recuperar energia e equilíbrio
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Transições de vida e crises: ressignificar e seguir adiante
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Conflitos relacionais e pessoais: compreender padrões e transformar relações
                </li>
              </ul>
            </Card>

            {/* Service 2 */}
            <Card className="card-minimal hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4 mb-4">
                <Briefcase className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <h3 className="font-display text-2xl text-primary">Orientação Profissional</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed mb-4">
                Suporte estruturado para decisões sobre carreira. Entendo que a escolha profissional não é apenas sobre um cargo ou função, mas sobre construir uma trajetória alinhada com sua identidade, bem-estar e objetivos. Auxilio em escolhas, transições e adaptações acadêmicas e profissionais.
              </p>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Escolha de curso e profissão
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Transições profissionais
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Adaptação acadêmica e profissional
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  Planejamento de carreira
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Method Section */}
      <section id="metodo" className="section-padding bg-secondary/10">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <h2 className="section-title mb-8">Como Funciona Nosso Trabalho</h2>
            <div className="accent-line mb-12"></div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <p className="text-lg text-foreground/80 leading-relaxed mb-6">
                  Acredito em um modelo de terapia <span className="font-semibold text-primary">horizontal</span>. Aqui, não há julgamentos ou rótulos. Trabalhamos em parceria: unindo o meu conhecimento clínico com a sua vivência prática.
                </p>
                
                <p className="text-lg text-foreground/80 leading-relaxed mb-6">
                  Juntos, vamos construir ferramentas para que você consiga compreender a si mesmo, lidar com as pressões institucionais e sociais, e retomar o controle da sua história.
                </p>

                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-semibold text-sm">1</div>
                    <div>
                      <h4 className="font-semibold text-primary mb-1">Escuta Empática</h4>
                      <p className="text-sm text-foreground/70">Escuto sua história e sua vivência sem julgamentos, reconhecendo o que você traz como válido</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-semibold text-sm">2</div>
                    <div>
                      <h4 className="font-semibold text-primary mb-1">Análise Colaborativa</h4>
                      <p className="text-sm text-foreground/70">Mapeamos juntos os padrões, as dificuldades e as possibilidades que emergem da sua experiência</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-semibold text-sm">3</div>
                    <div>
                      <h4 className="font-semibold text-primary mb-1">Construção de Ferramentas</h4>
                      <p className="text-sm text-foreground/70">Desenvolvemos estratégias práticas e sustentáveis que funcionam na sua vida real, aqui e agora</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative h-96">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028397627/Htz5MNH74SXz44txpSQmVV/trust-connection-9igD3j3LmyPbNZhiWNePeZ.webp"
                  alt="Conexão e Confiança"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Terapia Colaborativa Section */}
      <section className="section-padding bg-secondary/5">
        <div className="container mx-auto max-w-4xl">
          <h2 className="section-title text-center mb-8">Terapia Colaborativa</h2>
          <div className="accent-line mx-auto mb-12"></div>

          <div className="space-y-12">
            {/* Intro */}
            <div className="text-center space-y-4">
              <p className="text-lg text-foreground/80 leading-relaxed">
                Meu trabalho é fundamentado na <span className="font-semibold text-primary">Terapia Colaborativa</span>, uma abordagem que reconhece você como o maior especialista na sua própria vida. Aqui, não há fórmulas prontas ou diagnósticos que definem quem você é.
              </p>
            </div>

            {/* 3 Pillars */}
            <div className="grid md:grid-cols-3 gap-8">
              {/* Pilar 1 */}
              <div className="bg-background rounded-lg p-6 border border-border hover:border-accent transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-accent text-white flex items-center justify-center font-bold">1</div>
                  <h3 className="font-semibold text-primary text-lg">Parceria</h3>
                </div>
                <p className="text-foreground/70 leading-relaxed">
                  Trabalho <span className="font-semibold">lado a lado</span> com você, não como um "juiz" que dita verdades. Você é o especialista na sua vida; juntos, desenvolvemos as ferramentas para organizá-la.
                </p>
              </div>

              {/* Pilar 2 */}
              <div className="bg-background rounded-lg p-6 border border-border hover:border-accent transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-accent text-white flex items-center justify-center font-bold">2</div>
                  <h3 className="font-semibold text-primary text-lg">Curiosidade</h3>
                </div>
                <p className="text-foreground/70 leading-relaxed">
                  Entramos em cada sessão com <span className="font-semibold">abertura genuína</span>, sem julgamentos prévios. Escutamos sua vivência e buscamos entender o mundo a partir da sua perspectiva.
                </p>
              </div>

              {/* Pilar 3 */}
              <div className="bg-background rounded-lg p-6 border border-border hover:border-accent transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-accent text-white flex items-center justify-center font-bold">3</div>
                  <h3 className="font-semibold text-primary text-lg">Diálogo</h3>
                </div>
                <p className="text-foreground/70 leading-relaxed">
                  A mudança acontece através de <span className="font-semibold">conversas intencionais</span>. Juntos, investigamos o que gera sofrimento e construímos novas formas de lidar com os desafios.
                </p>
              </div>
            </div>

            {/* How it works */}
            <div className="bg-background rounded-lg p-8 border border-border">
              <h3 className="font-semibold text-primary text-lg mb-4">Como Funciona na Prática</h3>
              <p className="text-foreground/70 leading-relaxed mb-4">
                O processo terapêutico é uma <span className="font-semibold">conversa intencional</span> onde ambos trazemos nossas contribuições. Você compartilha sua vivência, suas dificuldades e o que você sente. Eu escuto com atenção, ajudo a identificar padrões e faço perguntas que abrem novas perspectivas.
              </p>
              <p className="text-foreground/70 leading-relaxed">
                Juntos, pegamos aquela demanda que está confusa, pesada ou travada no seu dia a dia e a reorganizamos. Não existem receitas prontas. Juntos, construímos estratégias reais e aplicáveis que fazem sentido para você, aqui e agora.
              </p>
            </div>

            {/* Benefits */}
            <div className="space-y-4">
              <h3 className="font-semibold text-primary text-lg">O Que Você Ganha</h3>
              <div className="space-y-3">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent text-white flex items-center justify-center mt-1">
                    <Heart className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Acolhimento sem Julgamentos</h4>
                    <p className="text-foreground/70">Um espaço seguro onde você pode colocar suas malas pesadas no chão sem medo de ser avaliado ou criticado. Aqui, sua vivência é válida e merece ser ouvida.</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent text-white flex items-center justify-center mt-1">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Alívio Imediato do Peso</h4>
                    <p className="text-foreground/70">A sensação de não estar sozinho nas crises. Aqui, você tem alguém que caminha com você, ajudando a reorganizar o que parece caótico.</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent text-white flex items-center justify-center mt-1">
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Autonomia e Clareza</h4>
                    <p className="text-foreground/70">Você desenvolve suas próprias ferramentas para organizar pensamentos, tomar decisões com mais segurança e lidar com conflitos futuros de forma mais leve. E sabe que pode contar com esse espaço sempre que precisar.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="section-padding">
        <div className="container mx-auto max-w-4xl">
          <h2 className="section-title mb-8">Sobre Mim</h2>
          <div className="accent-line mb-12"></div>

          <div className="space-y-6 text-foreground/80 leading-relaxed">
            <p>
              Sou Psicólogo graduado pela Universidade de São Paulo (USP), com Bacharelado e Licenciatura. Minha trajetória profissional é marcada pelo compromisso com uma psicologia que entende o ser humano para além dos diagnósticos, focando em como nossas histórias e os contextos em que vivemos moldam quem somos.
            </p>

            <p>
              Atuo em duas frentes que se complementam: o acolhimento do sofrimento emocional e o suporte estratégico para as trajetórias de carreira.
            </p>

            <div className="bg-secondary/10 border-l-4 border-accent p-6 rounded-lg my-8">
              <h4 className="font-semibold text-primary mb-3">No Consultório</h4>
              <p>
                Meu trabalho é oferecer um suporte seguro e acolhedor para que você consiga enfrentar as pressões que o dia a dia nos impõe. Tenho experiência no manejo clínico de quadros de depressão, ansiedade e exaustão emocional, e compreendo profundamente como esses sentimentos muitas vezes surgem de uma sobrecarga social e institucional. Não é fraqueza pessoal, mas uma resposta legítima a pressões reais. Juntos, exploramos essas raízes e desenvolvemos formas de reorganizar sua vida com mais leveza e autonomia.
              </p>
            </div>

            <div className="bg-secondary/10 border-l-4 border-accent p-6 rounded-lg my-8">
              <h4 className="font-semibold text-primary mb-3">Na Orientação de Carreira</h4>
              <p>
                Minha formação e pesquisa na USP me permitem trazer um olhar diferenciado e fundamentado para as questões de Orientação Profissional. Trabalho com jovens em momentos cruciais de escolha de curso, universitários enfrentando adaptação acadêmica e adultos em transições profissionais. O foco é compreender suas dificuldades, diminuir a angústia diante das decisões e construir juntos um planejamento que faça sentido com sua realidade, seus valores e suas aspirações.
              </p>
            </div>

            <p className="text-lg font-semibold text-primary">
              Minha Filosofia de Trabalho
            </p>

            <p>
              Acredito em uma escuta empática e livre de julgamentos. Meu objetivo é que, ao final de cada encontro, você se sinta mais fortalecido e preparado para lidar com as pressões externas, sabendo que pode contar com esse espaço sempre que precisar. Seja para cuidar da sua saúde mental ou para desenhar seus próximos passos profissionais, construiremos esse caminho juntos.
            </p>
          </div>
        </div>
      </section>

      {/* Career Journey Section */}
      <section className="section-padding bg-muted/30">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <img 
                src="/manus-storage/career-journey-autonomia-final_7a8ee431.png"
                alt="Sua Jornada é Única - Reflexão, Escolhas, Direção, Autonomia"
                className="w-full h-auto object-contain rounded-2xl"
              />
            </div>

            <div className="order-1 md:order-2">
              <h3 className="font-display text-3xl text-primary mb-6">Sua Jornada é Única</h3>
                <p className="text-foreground/80 leading-relaxed">
                Cada pessoa traz uma história diferente, com desafios e potencialidades próprias. Não existem soluções prontas ou caminhos únicos. O que funciona para um pode não funcionar para outro.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                Por isso, nosso trabalho é sempre personalizado, respeitando seu tempo, suas limitações e seus desejos. Você é o maior especialista na sua própria vida; juntos, desenvolvemos o método que funciona para você.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Notice */}
      <section className="bg-red-50 border-t-4 border-red-500 py-6">
        <div className="container mx-auto">
          <div className="flex gap-4 items-start">
            <div className="flex-shrink-0">
              <AlertCircle className="w-6 h-6 text-red-600 mt-0.5" />
            </div>
            <div>
              <h3 className="font-semibold text-red-900 mb-2">Em Caso de Emergência</h3>
              <p className="text-sm text-red-800 mb-3">
                Se você está sentindo vontade de se machucar ou se sente sem saída neste momento, você não está sozinho. Procure ajuda profissional agora - existem pessoas treinadas para caminhar com você nessa crise:
              </p>
              <div className="flex flex-wrap gap-4 text-sm">
                <div>
                  <span className="font-semibold text-red-900">CVV (Prevenção ao Suicídio):</span>
                  <a href="tel:188" className="text-red-700 hover:text-red-900 ml-2 font-semibold">188</a>
                </div>
                <div>
                  <span className="font-semibold text-red-900">SAMU (Emergência):</span>
                  <a href="tel:192" className="text-red-700 hover:text-red-900 ml-2 font-semibold">192</a>
                </div>
                <div>
                  <span className="font-semibold text-red-900">Polícia:</span>
                  <a href="tel:190" className="text-red-700 hover:text-red-900 ml-2 font-semibold">190</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="section-padding">
        <div className="container mx-auto max-w-3xl">
          <h2 className="section-title text-center mb-8">Perguntas Frequentes</h2>
          <div className="accent-line mx-auto mb-12"></div>

          <div className="space-y-4">
            {[
              {
                q: "O atendimento é online?",
                a: "Sim, todos os atendimentos são realizados de forma online através de videoconferência segura. Você pode participar de qualquer lugar, desde que tenha privacidade e uma boa conexão com a internet."
              },
              {
                q: "Quanto tempo dura uma sessão?",
                a: "Cada sessão tem duração de 50 minutos. Este tempo é dedicado exclusivamente a você, permitindo uma conversa profunda e focada."
              },
              {
                q: "O que acontece na primeira sessão?",
                a: "Na primeira sessão, nos conhecemos melhor. Você compartilha o que o trouxe até aqui e eu escuto com atenção, sem julgamentos. Juntos, avaliamos se há sintonia e como podemos trabalhar em parceria. Também explico como funciona nosso trabalho e esclarecemos dúvidas. Esta sessão é uma oportunidade para você avaliar se se sente confortável comigo."
              },
              {
                q: "Com que frequência devo fazer sessões?",
                a: "A frequência depende de suas necessidades e objetivos. Geralmente, começamos com uma sessão semanal, mas isso pode variar. Discutiremos juntos qual é o melhor ritmo para você."
              },
              {
                q: "Como funciona o agendamento?",
                a: "Você pode entrar em contato comigo via WhatsApp para agendar sua primeira sessão. Oferecerei horários disponíveis e confirmaremos o melhor para você."
              },
              {
                q: "Qual é o valor das sessões?",
                a: "Vamos conversar sobre isso na primeira sessão, encontrando uma opção que funcione para você. Acredito que o investimento em saúde mental deve ser acessível e sustentável."
              },
              {
                q: "Meus dados estão seguros?",
                a: "Sim. Todos os seus dados são protegidos conforme a Lei Geral de Proteção de Dados (LGPD). Mantemos sigilo profissional absoluto sobre tudo que é compartilhado em sessão."
              }
            ].map((item, index) => (
              <div key={index} className="border border-secondary rounded-lg overflow-hidden">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-secondary/5 transition-colors"
                >
                  <span className="font-semibold text-primary text-left">{item.q}</span>
                  <ChevronDown 
                    className={`w-5 h-5 text-accent flex-shrink-0 transition-transform ${expandedFaq === index ? 'rotate-180' : ''}`}
                  />
                </button>
                {expandedFaq === index && (
                  <div className="px-6 py-4 bg-secondary/5 border-t border-secondary">
                    <p className="text-foreground/80 leading-relaxed">{item.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container mx-auto text-center space-y-8">
          <h2 className="font-display text-4xl md:text-5xl font-bold">
            Pronto para começar essa jornada juntos?
          </h2>
          
          <p className="text-lg max-w-2xl mx-auto opacity-90">
            Agende sua primeira sessão hoje. Vamos conversar sobre seus desafios e explorar juntos as possibilidades de mudança.
          </p>

          <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
            <Button className="btn-primary bg-secondary text-secondary-foreground hover:bg-secondary/90">
              Agendar Agora via WhatsApp
            </Button>
          </a>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="section-padding bg-muted/30">
        <div className="container mx-auto max-w-2xl">
          <h2 className="section-title text-center mb-12">Entre em Contato</h2>
          <div className="accent-line mx-auto mb-12"></div>

          <div className="flex justify-center">
            <div className="text-center">
              <MessageCircle className="w-8 h-8 text-accent mx-auto mb-4" />
              <h4 className="font-semibold text-primary mb-2">WhatsApp</h4>
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="text-accent hover:text-primary transition-colors">
                {phoneNumber}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8">
        <div className="container mx-auto text-center space-y-4">
          <p className="text-sm opacity-80">
            © 2026 {psychologistName}. Todos os direitos reservados.
          </p>
          <p className="text-xs opacity-70">
            Atendimento psicológico online | Psicoterapia Colaborativa | Orientação de Carreira
          </p>
          <p className="text-xs opacity-70">
            Conselho Regional de Psicologia - CRP {crpNumber}
          </p>
          <p className="text-xs opacity-70">
            {psychologistName} - Psicólogo Clínico
          </p>
        </div>
      </footer>
    </div>
  );
}

# Ideias de Design - Site de Psicologia

## Contexto
Site profissional de página única para psicólogo especializado em psicoterapia clínica e orientação de carreira. A identidade visual deve transmitir calma, clareza, estrutura e acolhimento, evitando misticismo ou frieza institucional.

---

## Resposta 1: Minimalismo Humanista com Tipografia Serifada

**Movimento de Design:** Modernismo Humanista (inspirado em design suíço com toque contemporâneo)

**Princípios Centrais:**
- Espaço generoso e respirável como ferramenta de conforto
- Tipografia serifada como marca de conhecimento estruturado
- Assimetria inteligente que guia o olhar naturalmente
- Paleta restrita que transmite clareza mental

**Filosofia de Cores:**
- Azul Marinho Profundo (#1F3A5C) como cor primária: transmite confiança, estabilidade e profissionalismo sem frieza
- Areia Quente (#E8DCC8) como cor de apoio: humaniza o design, evoca consultório acolhedor
- Off-white Perolado (#F9F7F3): reduz fadiga visual, cria sensação de tranquilidade
- Acentos em Terracota Suave (#C9A876): traz calor e vitalidade sem ser agressivo

**Paradigma de Layout:**
- Hero section assimétrico: foto do psicólogo à direita com recorte diagonal suave, texto à esquerda
- Blocos de conteúdo com alinhamento à esquerda, criando ritmo visual
- Uso de linhas horizontais sutis como divisores entre seções
- Grid de 3 colunas em desktop, colapsando para 1 em mobile

**Elementos Assinatura:**
- Linha horizontal em Areia Quente separando seções (2px, com espaço gerado)
- Pequeno ícone de "conversa" ou "caminho" em Terracota Suave ao lado de títulos
- Cards com borda esquerda em Azul Marinho (3px) em vez de sombra

**Filosofia de Interação:**
- Hover subtil: mudança de cor de texto para Azul Marinho, sem animação excessiva
- Botões com fundo Azul Marinho, texto branco, sem sombra (design limpo)
- Links com sublinhado em Terracota Suave ao hover

**Animação:**
- Fade-in suave (200ms) ao entrar na página
- Scroll reveal: elementos aparecem com fade-in leve conforme o usuário desce
- Transições de cor em 300ms (hover em botões e links)
- Nenhuma animação excessiva ou distratora

**Sistema Tipográfico:**
- Títulos: Playfair Display (serifada, elegante, peso 700)
- Subtítulos: Lora (serifada, peso 600)
- Corpo: Inter (sans-serif, peso 400, line-height 1.6)
- Chamadas de ação: Inter, peso 600, maiúsculas

**Probabilidade:** 0.08

---

## Resposta 2: Warmth Moderno com Gradientes Sutis

**Movimento de Design:** Contemporâneo Acolhedor (inspirado em design de wellness moderno)

**Princípios Centrais:**
- Gradientes suaves que evocam transição e movimento
- Tipografia moderna mas humanizada
- Composição em blocos fluidos, não rígida
- Uso estratégico de ilustrações abstratas

**Filosofia de Cores:**
- Gradiente primário: de Azul Ardósia (#2C5282) para Azul Claro (#4A90E2), criando movimento
- Tons terrosos: Bege Quente (#DCC9B8), Terracota (#D4845C)
- Fundo: Branco com leve toque de bege (#FDFBF7)
- Acentos em Verde Menta Suave (#A8D5BA): esperança e crescimento

**Paradigma de Layout:**
- Seções com fundo alternado: uma com gradiente suave, outra com fundo sólido
- Hero com imagem de fundo desfocada (luz natural) com overlay de gradiente
- Blocos de conteúdo com cantos arredondados (12px) e sombra suave
- Layout em "Z": conteúdo flui em padrão natural de leitura

**Elementos Assinatura:**
- Pequenos círculos decorativos em Menta Suave espalhados sutilmente
- Ícones customizados (conversa, caminho, crescimento) em Terracota
- Separadores em forma de onda suave entre seções

**Filosofia de Interação:**
- Botões com gradiente sutil ao hover
- Cards que se elevam levemente ao passar o mouse (3px de lift)
- Transições fluidas em 400ms

**Animação:**
- Entrance animation: elementos deslizam suavemente de baixo para cima (300ms)
- Scroll trigger: cards aparecem com fade + slide ao entrar na viewport
- Ícones com micro-animação ao hover (rotação leve de 5 graus)
- Botão com pulse sutil para chamar atenção

**Sistema Tipográfico:**
- Títulos: Lora (serifada, peso 700, elegante)
- Subtítulos: Lora, peso 600
- Corpo: Lato (sans-serif, peso 400, amigável)
- Destaque: Lato, peso 700

**Probabilidade:** 0.07

---

## Resposta 3: Estruturalismo Clínico com Tipografia Contraste Extremo

**Movimento de Design:** Brutalismo Digital Refinado (inspirado em design clínico moderno)

**Princípios Centrais:**
- Contraste tipográfico extremo: serifada muito pesada vs. sans-serif muito leve
- Estrutura clara e previsível (grid rigoroso)
- Uso mínimo de cor, máximo de tipografia como elemento visual
- Honestidade visual: sem ornamentação, apenas essencial

**Filosofia de Cores:**
- Monocromático com acentos: Preto (#1A1A1A), Cinza Claro (#F0F0F0)
- Azul Marinho (#1F3A5C) como único acento cromático
- Fundo: Branco puro (#FFFFFF)
- Sem gradientes, apenas cores sólidas

**Paradigma de Layout:**
- Grid rigoroso de 12 colunas, respeitado estritamente
- Hero: texto grande e ousado à esquerda, foto à direita em moldura simples
- Blocos com espaçamento generoso (múltiplos de 32px)
- Alinhamento à esquerda em tudo, criando leitura natural

**Elementos Assinatura:**
- Barra vertical em Azul Marinho (1px) ao lado de citações ou destaque
- Números grandes em Azul Marinho para estatísticas ou etapas
- Moldura simples (1px preto) ao redor de imagens

**Filosofia de Interação:**
- Hover: mudança de cor para Azul Marinho, sem animação
- Botões com borda (2px) em Azul Marinho, fundo transparente, texto preto
- Links com sublinhado simples em Azul Marinho

**Animação:**
- Mínima: apenas fade-in ao carregar (100ms)
- Sem scroll reveal ou micro-animações
- Transições de cor em 200ms
- Foco em clareza, não em movimento

**Sistema Tipográfico:**
- Títulos: Playfair Display (serifada, peso 900, muito ousado)
- Subtítulos: Playfair Display, peso 700
- Corpo: Inter (sans-serif, peso 300, muito leve)
- Contraste extremo entre seções

**Probabilidade:** 0.06

---

## Design Escolhido: **Minimalismo Humanista com Tipografia Serifada**

Escolhi a **Resposta 1** porque melhor equilibra os valores do seu trabalho:

1. **Confiança + Humanidade:** O Azul Marinho transmite profissionalismo (USP, conhecimento), enquanto Areia Quente humaniza e torna acolhedor
2. **Clareza Mental:** O espaço generoso e a tipografia serifada refletem o método colaborativo: sem confusão, apenas essencial
3. **Escalabilidade:** Funciona bem em mobile e desktop sem perder identidade
4. **Diferenciação:** Evita o clichê de sites de psicologia (muito místico ou muito frio)
5. **Acessibilidade:** Tipografia clara, contraste adequado, sem animações distratoras

Este design comunica: "Aqui você é ouvido com estrutura e cuidado."

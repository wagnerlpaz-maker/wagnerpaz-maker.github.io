# TODO - Personalização do Site de Psicologia

## Informações do Psicólogo (Aguardando)
- [ ] Nome completo
- [ ] Número do CRP (Conselho Regional de Psicologia)
- [ ] Telefone/WhatsApp para contato
- [ ] Email profissional
- [ ] Foto profissional (opcional mas recomendado)
- [ ] Cidade/Estado de atuação

## Atualizações Necessárias no Site
- [ ] Substituir contatos fictícios pelos reais
- [ ] Incluir número do CRP no rodapé e seção "Sobre"
- [ ] Adicionar foto profissional no hero section (se fornecida)
- [ ] Atualizar links de WhatsApp com número real
- [ ] Adicionar email real nos contatos
- [ ] Adicionar telefone real nos contatos

## Conformidade Ética
- [ ] Adicionar aviso de emergência (CVV, SAMU)
- [ ] Incluir política de privacidade (LGPD)
- [ ] Adicionar termos de serviço
- [ ] Criar página de consentimento informado
- [ ] Adicionar informações sobre limitações do atendimento online
- [ ] Incluir disclaimer sobre o site ser informativo

## Otimizações Finais
- [ ] Testar responsividade em mobile
- [ ] Testar links de contato
- [ ] Verificar acessibilidade (contraste, navegação)
- [ ] Otimizar imagens para carregamento rápido
- [ ] Adicionar meta tags para SEO
- [ ] Testar em diferentes navegadores

## Deploy
- [ ] Criar checkpoint final
- [ ] Revisar todas as informações
- [ ] Publicar no Manus
- [ ] Configurar domínio customizado (opcional)

---

**Status:** Aguardando informações do usuário
**Última atualização:** 07/05/2026
